TRANSFORM Format(Sum([Order Details].[UnitPrice]*[Order Details].[Quantity]*(1 - [Order Details].Discount)),"$#,##0") AS Sales
SELECT Categories.CategoryName
FROM (Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID) INNER JOIN (Orders INNER JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID) ON Products.ProductID = [Order Details].ProductID
WHERE (((Orders.OrderDate) Between #1/1/95# And #12/31/95#))
GROUP BY Categories.CategoryName
ORDER BY Categories.CategoryName
PIVOT Format([OrderDate],"yyyy\Qq")

